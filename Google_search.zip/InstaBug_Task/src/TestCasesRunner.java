import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestCasesRunner {

	public WebDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeTest
	public void invoke_website() {
		driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.google.com");
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.google.com/");
	}

	@Test
	public void Search_for_instabug_manually() {

		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.google.com/");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("InstaBug");
		driver.findElement(By.xpath("//input[@value='Google Search']")).click();

	}

	@Test
	public void search_for_instabug_by_uploading_image() {
		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		driver.findElement(By.xpath("(//*[name()='svg'][@class='Gdd5U'])[1]")).click();
		driver.findElement(By.xpath("//div[@class='lJ9FBc']//input[@name='btnK']")).click();

	}

	@Test
	public void search_for_instabug_by_image_link() {
		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Paste image link']"))
				.sendKeys("https://i.ytimg.com/vi/ZFSy5nrZn20/sddefault.jpg");
		driver.findElement(By.xpath("//div[@role='button'][normalize-space()='بحث']")).click();
	}

	@Test
	public void user_try_to_login() throws InterruptedException {
		Actions a = new Actions(driver);
		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		driver.findElement(By.xpath("//span[@class='gb_Hd']")).click();
		driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("instatask365@gmail.com");
		driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
		ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Passwd']"));
		driver.findElement(By.xpath("//input[@name='Passwd']")).sendKeys("123456789insta");
		a.sendKeys(Keys.ENTER).perform();

	}

	@Test
	public void user_want_to_look_for_news() {
		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.google.com/");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("InstaBug");
		driver.findElement(By.xpath("//input[@value='Google Search']")).click();
		ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//a[normalize-space()='News']")));
		driver.findElement(By.xpath("//a[normalize-space()='News']")).click();
	}

	@Test
	public void user_want_to_look_for_videos() {
		driver.findElement(By.xpath("//a[normalize-space()='English']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.google.com/");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("InstaBug");
		driver.findElement(By.xpath("//input[@value='Google Search']")).click();
		ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//a[normalize-space()='Videos']")));
		driver.findElement(By.xpath("//a[normalize-space()='Videos']")).click();
	}
//	@AfterTest
//	public void closing_website() throws InterruptedException {
//		driver.close();
//	}

}
